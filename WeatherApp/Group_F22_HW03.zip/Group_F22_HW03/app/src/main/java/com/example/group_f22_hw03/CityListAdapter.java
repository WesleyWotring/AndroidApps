package com.example.group_f22_hw03;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CityListAdapter extends ArrayAdapter<Data.City> {

    public CityListAdapter(@NonNull Context context, int resource, @NonNull List<Data.City> objects) {
        super(context, resource, objects);
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.city_list_layout, parent, false);
        }
        Data.City city = getItem(position);

        TextView cityName = convertView.findViewById(R.id.textViewCity);
        TextView country = convertView.findViewById(R.id.textViewCountry);

        cityName.setText(city.getCity());
        country.setText(city.getCountry());

        return convertView;
    }
}
