package com.example.group_f22_hw03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements CitiesListFragment.CityListFragmentListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.containerView, new CitiesListFragment(), "start")
                .commit();


    }


    @Override
    public void gotoCity(Data.City selectedCity) {
        getSupportFragmentManager().beginTransaction()
                .add(R.id.containerView, new CurrentWeatherFragment(/**selectedCity**/), "citySelected")
                .addToBackStack(null)
                .commit();

    }
}