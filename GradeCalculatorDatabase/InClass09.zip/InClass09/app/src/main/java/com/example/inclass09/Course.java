package com.example.inclass09;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "courses")
public class Course {

    @PrimaryKey (autoGenerate = true)
    public long id;

    @ColumnInfo
    public String courseNum;

    @ColumnInfo
    public String courseName;

    @ColumnInfo
    int courseHours;

    @ColumnInfo
    char courseGrade;

    public Course(long id, String courseNum, String courseName, int courseHours, char courseGrade) {
        this.id = id;
        this.courseNum = courseNum;
        this.courseName = courseName;
        this.courseHours = courseHours;
        this.courseGrade = courseGrade;
    }

    public Course(String courseNum, String courseName, int courseHours, char courseGrade) {
        this.courseNum = courseNum;
        this.courseName = courseName;
        this.courseHours = courseHours;
        this.courseGrade = courseGrade;
    }

    public Course() {
    }


    @Override
    public String toString() {
        return "Course{" +
                "courseNum='" + courseNum + '\'' +
                ", courseName='" + courseName + '\'' +
                ", courseHours=" + courseHours +
                ", courseGrade=" + courseGrade +
                '}';
    }
}
