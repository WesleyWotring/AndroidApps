package com.example.inclass08;

import java.util.Date;

public class Forum {
    String name, title, description;
    Date date;

    public Forum(String name, String title, String description, Date date) {
        this.name = name;
        this.title = title;
        this.description = description;
        this.date = date;
    }

    public Forum() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
