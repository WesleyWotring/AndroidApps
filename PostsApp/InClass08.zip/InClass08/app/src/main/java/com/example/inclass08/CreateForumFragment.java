package com.example.inclass08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CreateForumFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CreateForumFragment extends Fragment {
    private static final String ARG_USER_TOKEN = "ARG_USER_TOKEN";
    private FirebaseAuth mAuth;
    FirebaseUser user;
    User currentUser = new User();

    View view;
    EditText title, description;
    String titleString, descriptionString;
    Button cancel, submit;
    String user_idCheck;



    public CreateForumFragment() {
        // Required empty public constructor
    }


    public CreateForumFragment newInstance() {
        CreateForumFragment fragment = new CreateForumFragment();
//        Bundle args = new Bundle();
//        args.putSerializable(ARG_USER_TOKEN, (Serializable) user);
//        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            user = (FirebaseUser) getArguments().getSerializable(ARG_USER_TOKEN);
//        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_create_forum, container, false);

        title = view.findViewById(R.id.editTextTitle);
        description = view.findViewById(R.id.editTextDescription);
        cancel = view.findViewById(R.id.buttonCancelForum);
        submit = view.findViewById(R.id.buttonSubmitForum);
        cancel.setText("Cancel");





        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                titleString = title.getText().toString();
                descriptionString = description.getText().toString();
                if(titleString.isEmpty() || descriptionString.isEmpty()){
                    Toast.makeText(getActivity(), R.string.fields, Toast.LENGTH_SHORT).show();
                }else{
                    //post the forum
                    ArrayList<User> userList = new ArrayList<>();
                    FirebaseFirestore db = FirebaseFirestore.getInstance();

                    db.collection("users").get()
                            .addOnCompleteListener(getActivity(), new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                    if (task.isSuccessful()) {
                                        if (task.getResult().size() > 0) {
                                            for (QueryDocumentSnapshot document : task.getResult()) {
                                                User user2 = new User();
                                                user2.setName(document.getString("name"));
                                                user2.setEmail(document.getString("email"));
                                                user2.setPassword(document.getString("password"));
                                                user2.setU_id(document.getString("user_id"));

                                                userList.add(user2);
                                                Log.d("demo", "List: " + userList);
                                            }
                                        } else {
                                            Toast.makeText(getActivity(), R.string.error + " " + task.getException(), Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        Toast.makeText(getActivity(), R.string.error + " " + task.getException(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                    mAuth = FirebaseAuth.getInstance();
                    user_idCheck = mAuth.getCurrentUser().getUid();

                    for(int i = 0; i <= userList.size(); i++){
                        if (user_idCheck.equals(userList.get(i).getU_id())){
                            currentUser = userList.get(i);
                        }
                    }
                    String userName = currentUser.getName();

                    FirebaseFirestore db2 = FirebaseFirestore.getInstance();

                    Forum forum = new Forum();
                    forum.setName(mAuth.getCurrentUser().getDisplayName());
                    forum.setTitle(titleString);
                    forum.setDescription(descriptionString);
                    forum.setDate(new Date());


                    db2.collection("forums")
                            .add(forum)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    mListener.createForum();
                                }
                            });

                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.cancelForum();
            }
        });

        return view;
    }

//    private void postForum(){
//
//    }


    CreateForumFragment.CreateForumFragmentListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (CreateForumFragment.CreateForumFragmentListener) context;
    }

    interface CreateForumFragmentListener {
        void cancelForum();
        void createForum();
    }


}