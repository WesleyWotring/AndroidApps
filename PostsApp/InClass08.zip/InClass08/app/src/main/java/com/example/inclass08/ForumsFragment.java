package com.example.inclass08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ForumsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ForumsFragment extends Fragment {
    private FirebaseAuth mAuth;
    private static final String ARG_USER_TOKEN = "ARG_USER_TOKEN";
    Button createPost, logout;
    RecyclerView forumsRecycler;
    View view;
    Forum forum;
    ArrayList<Forum> forumArrayList = new ArrayList<>();
    ForumAdapter adapter;
    LinearLayoutManager manager;

    FirebaseUser user;

    public ForumsFragment() {
        // Required empty public constructor
    }


    public static ForumsFragment newInstance() {
        ForumsFragment fragment = new ForumsFragment();
//        Bundle args = new Bundle();
//        args.putSerializable(ARG_USER_TOKEN, (Serializable) user);
//        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        if (getArguments() != null) {
//            user = (FirebaseUser) getArguments().getSerializable(ARG_USER_TOKEN);
//
//        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_forums, container, false);

        logout = view.findViewById(R.id.buttonLogOut);
        createPost = view.findViewById(R.id.buttonCreatePost);
        forumsRecycler = view.findViewById(R.id.list);


        forumArrayList.clear();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("forums").get()
                .addOnCompleteListener(getActivity(), new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {

                        if (task.isSuccessful()) {
                            if (task.getResult().size() > 0) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    forum = document.toObject(Forum.class);
                                    forumArrayList.add(forum);


                                    getActivity().runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {

                                            forumsRecycler.setHasFixedSize(true);
                                            manager = new LinearLayoutManager(getActivity());
                                            forumsRecycler.setLayoutManager(manager);

                                            //JUST FOR YOU CARLOS
                                            DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(forumsRecycler.getContext(),
                                                    manager.getOrientation());
                                            forumsRecycler.addItemDecoration(dividerItemDecoration);

                                            adapter = new ForumAdapter(forumArrayList /**,user**/);
                                            forumsRecycler.setAdapter(adapter);

                                            db.collection("forums")
                                                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                                                        @Override
                                                        public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                                                            forumArrayList.clear();
                                                            for(QueryDocumentSnapshot document : value){
                                                                Forum forumUpdate = new Forum(document.getString("name"),document.getString("title"),document.getString("description"),document.getDate("date"));
                                                                forumArrayList.add(forumUpdate);
                                                            }
                                                            adapter.notifyDataSetChanged();
                                                        }
                                                    });

                                        }
                                    });


                                }
                            } else {
                                Toast.makeText(getActivity(), R.string.error + " " + task.getException(), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getActivity(), R.string.error + " " + task.getException(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                mListener.logout();

            }
        });

        createPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.goToCreateForum();
            }
        });


        return view;
    }


    ForumsFragment.ForumsFragmentListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (ForumsFragment.ForumsFragmentListener) context;
    }


    interface ForumsFragmentListener {
        void logout();
        void goToCreateForum();
    }


    public class ForumAdapter extends RecyclerView.Adapter<ForumAdapter.ForumViewHolder> {
        ArrayList<Forum> forumsList;
        //FirebaseUser user = mAuth.getCurrentUser();
       // String userId = user.getUid();


        public ForumAdapter(ArrayList<Forum> forumsList /**,FirebaseUser user**/ ) {
            this.forumsList = forumsList;
           // this.user = user;
        }

        @NonNull
        @Override
        public ForumAdapter.ForumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forums_layout, parent, false);
            ForumAdapter.ForumViewHolder forumViewHolder = new ForumAdapter.ForumViewHolder(view);

            return forumViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull ForumAdapter.ForumViewHolder holder, int position) {

            Forum forum = forumsList.get(position);
            holder.name.setText(forum.getName());
            holder.time.setText(forum.getDate().toString());
            holder.desc.setText(forum.getDescription());
            holder.title.setText(forum.getTitle());

//
//            if(user.getDisplayName().equals(forum.name)){
//                holder.delete.setVisibility(View.VISIBLE);
//            }else{
//                holder.delete.setVisibility(View.INVISIBLE);
//            }

            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // deletePost(forum);
                }
            });


        }

        @Override
        public int getItemCount() {
            return this.forumsList.size();
        }

        public class ForumViewHolder extends RecyclerView.ViewHolder {
            ImageView delete;
            TextView name, desc, time, title;


            public ForumViewHolder(@NonNull View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.textViewName);
                title = itemView.findViewById(R.id.textViewTitle);
                desc = itemView.findViewById(R.id.textViewDesc);
                time = itemView.findViewById(R.id.textViewTime);

                delete = itemView.findViewById(R.id.imageViewDelete);


            }
        }

    }
}